#!/bin/sh

# Author	KMS -	Martin Dubois, ing.
# Client	Coveloz
# Product	buildroot
# File		env/nios2_create_hex.sh
# Usage		env/nios2_create_hex.sh

echo  Executing env/nios2_create_hex.sh

ALTERA=/altera/15.0
NIOS=$ALTERA/nios2eds
NIOS_BIN=$NIOS/bin
NIOS_BIN_GNU=$NIOS_BIN/gnu/H-x86_64-pc-linux-gnu/bin

$NIOS_BIN_GNU/nios2-elf-objcopy -O ihex -I binary output/images/rootfs.jffs2 output/images/rootfs.hex

if [ 0 != $? ] ; then
    echo  ERROR : nios2-elf-objcopy reported an error
    exit 1
fi

echo  OK : output/images/rootfs.hex created

